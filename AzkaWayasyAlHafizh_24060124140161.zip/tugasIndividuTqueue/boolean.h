#ifndef boolean_H
#define boolean_H
/*Deskripsi : boolean*/
/* NIM/Nama  : 24060124140161/Azka Wayasy Al Hafizh*/
/* Tanggal   : 8 Oktober 2025*/
#define true 1
#define false 0
#define boolean unsigned char
#endif
