/* Program   : mmatriks.c */
/* Deskripsi : driver ADT matriks integer */
/* NIM/Nama  : */
/* Tanggal   : */
/***********************************/

#include <stdio.h>

int main() {
	/*kamus*/
	
	/*algoritma*/
	
	return 0;
}
