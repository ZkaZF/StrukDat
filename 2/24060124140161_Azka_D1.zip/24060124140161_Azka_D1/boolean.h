#ifndef boolean_H
#define boolean_H
/*Deskripsi : boolean*/
/* NIM/Nama  : 24060123120009/Indah Nurul Janah*/
/* Tanggal   : 13 September 2024*/
#define true 1
#define false 0
#define boolean unsigned char
#endif