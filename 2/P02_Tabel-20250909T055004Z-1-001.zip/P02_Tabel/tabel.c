#ifndef   tabel_c
#define   tabel_c
#include "tabel.h"
/* Deskripsi : */
/* NIM/Nama : */
/* Tanggal : */


#endif