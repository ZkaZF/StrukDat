/************************************/
/* Program   : maintitik.c */
/* Deskripsi : aplikasi driver modul Titik */
/* NIM/Nama  : */
/* Tanggal   : */
/***********************************/
#include <stdio.h>
#include "titik.h"

int main() {
	//kamus main
	//Titik T1;
	
	//algoritma
	printf("Halo, ini driver modul Titik /n");
	//makeTitik(&T1,4,5);
	//printf("/nNilai absis = %d",getAbsis(T1));
	
	return 0;
}
