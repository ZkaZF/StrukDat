    printf("Apakah Queue Q1 kosong? %s\n", isEmptyQueue3(Q1) ? "true" : "false");
    printf("Apakah Queue Q1 penuh? %s\n", isFullQueue3(Q1) ? "true" : "false");